#!/usr/bin/env python3
"""Live-smoke hook: run one authored task against the real BrachyBot.

This is the bridge from "replay" to a real SUT.  It is **safe to run without
credentials**: if no provider key is configured it prints ``BLOCKED`` and exits
0 (so CI stays green).  With credentials it drives ``BrachyAgent.chat_with_trace``
through :mod:`tools.adapters.brachybot` and scores one task.

    # dry check (no credentials needed)
    python tools/live_smoke.py --task tasks/D1-SA-007.json
    # live run
    ANTHROPIC_API_KEY=... python tools/live_smoke.py --task tasks/D1-SA-007.json
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any, Dict, Optional

HERE = os.path.dirname(os.path.abspath(__file__))
BB = os.path.abspath(os.path.join(HERE, ".."))
REPO = os.path.abspath(os.path.join(BB, "..", ".."))
sys.path.insert(0, BB)

_KEY_ENVS = ("ANTHROPIC_API_KEY", "BRACHYBOT_API_KEY", "OPENAI_API_KEY",
             "DEEPSEEK_API_KEY", "GEMINI_API_KEY")


def _has_credentials() -> bool:
    return any(os.environ.get(k) for k in _KEY_ENVS)


def _agent_factory(task: Dict[str, Any], initial_state: Dict[str, Any]):
    """Build the real BrachyAgent for one task (case-scoped session)."""
    sys.path.insert(0, REPO)
    from AgenticSys import BrachyAgent  # noqa: WPS433

    session = f"brachybench-{task['id']}"
    agent = BrachyAgent(session_id=session)

    def observation_state():
        # Best-effort: read the agent's current world-state snapshot if exposed.
        for attr in ("observation_state", "cws_snapshot", "world_state"):
            fn = getattr(agent, attr, None)
            if callable(fn):
                try:
                    return dict(fn() or {})
                except Exception:  # noqa: BLE001
                    return {}
        return {}

    agent.observation_state = observation_state  # adapter reads this
    return agent


def main(argv: Optional[list] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--task", default=os.path.join(BB, "tasks", "D1-SA-007.json"))
    ap.add_argument("--out", default="results/live")
    args = ap.parse_args(argv)

    with open(args.task, encoding="utf-8") as fh:
        task = json.load(fh)

    if not _has_credentials():
        print(f"BLOCKED: no provider credential in {_KEY_ENVS}; "
              f"set one to run {task['id']} live. (This is expected, not a failure.)")
        return 0

    from tools import run_task as rt  # noqa: E402
    from tools.adapters import brachybot  # noqa: E402

    brachybot.set_agent_factory(_agent_factory)
    adapter = rt.PythonAdapter("tools.adapters.brachybot:observe_task")
    outcome = rt.run_task(task, adapter, args.out)
    print(f"{task['id']}: {outcome['evaluation']['verdict']}")
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, f"{task['id']}.live.json"), "w", encoding="utf-8") as fh:
        json.dump(outcome["evaluation"], fh, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

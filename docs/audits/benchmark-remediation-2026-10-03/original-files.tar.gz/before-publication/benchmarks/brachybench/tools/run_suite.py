#!/usr/bin/env python3
"""E0 smoke suite: run every authored task that has a recorded observation.

Non-zero exit if any task does not reach ``Meets`` -- this is the PRV-side E0
gate of DESIGN §26.  Tasks without a replay observation (they need a live SUT)
are reported as ``SKIPPED-live`` rather than silently passed.

    python tools/run_suite.py --tasks-dir tasks --replay-dir tests/replay --out results
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any, Dict, List, Optional

HERE = os.path.dirname(os.path.abspath(__file__))
BB = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, BB)

from oracles import Verdict  # noqa: E402
from tools import run_task as rt  # noqa: E402
from tools import score_report as sr  # noqa: E402
from tools import panel_report as pr  # noqa: E402


def _authored_tasks(tasks_dir: str) -> List[Dict[str, Any]]:
    out = []
    for dirpath, _, files in sorted(os.walk(tasks_dir)):
        for fn in sorted(files):
            if fn.endswith(".json"):
                with open(os.path.join(dirpath, fn), encoding="utf-8") as fh:
                    out.append(json.load(fh))
    return out


def run_suite(tasks_dir: str, replay_dir: str, out: str) -> Dict[str, Any]:
    adapter = rt.ReplayAdapter(replay_dir)
    rows = []
    for task in _authored_tasks(tasks_dir):
        tid = task["id"]
        replay = os.path.join(replay_dir, f"{tid}.json")
        if not os.path.isfile(replay):
            rows.append({"task_id": tid, "track": task.get("track"),
                         "verdict": "SKIPPED-live", "ok": True})
            continue
        outcome = rt.run_task(task, adapter, out)
        verdict = outcome["evaluation"]["verdict"]
        item = outcome["evaluation"].get("item_score") or {}
        scenario = ((task.get("anti_gaming") or {}).get("paraphrase_group")
                    or (task.get("unit") or {}).get("contrast_family_id") or tid)
        rows.append({"task_id": tid, "track": task.get("track"), "scenario": scenario,
                     "weight": (task.get("scoring") or {}).get("weight", 1.0),
                     "verdict": verdict, "ok": verdict == Verdict.MEETS.value,
                     "score": item.get("value"), "coverage": item.get("coverage"),
                     "n_a_reason": item.get("n_a_reason")})
    n_ok = sum(1 for r in rows if r["ok"])
    failed = [r for r in rows if not r["ok"]]
    scored = [{"track": r["track"], "scenario": r["scenario"], "verdict": r["verdict"],
               "value": r["score"], "coverage": r["coverage"],
               "n_a_reason": r["n_a_reason"]} for r in rows]
    summary = {
        "n_tasks": len(rows),
        "n_ok": n_ok,
        "n_failed": len(failed),
        "score_summary": sr.aggregate(scored),
        "panel_report": pr.report(scored, n_boot=1000),
        "rows": rows,
    }
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "e0_prv_suite.json"), "w", encoding="utf-8") as fh:
        json.dump(summary, fh, ensure_ascii=False, indent=2, sort_keys=True)
        fh.write("\n")
    with open(os.path.join(out, "pilot_report.md"), "w", encoding="utf-8") as fh:
        fh.write(pr.render_markdown(summary["panel_report"]))
    return summary


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--tasks-dir", default=os.path.join(BB, "tasks"))
    ap.add_argument("--replay-dir", default=os.path.join(BB, "tests", "replay"))
    ap.add_argument("--out", default="results")
    args = ap.parse_args(argv)

    summary = run_suite(args.tasks_dir, args.replay_dir, args.out)
    for r in summary["rows"]:
        mark = "OK" if r["ok"] else "FAIL"
        print(f"  [{mark:4s}] {r['task_id']:16s} track={r['track'] or '?':3s} {r['verdict']}")
    print(f"E0 PRV smoke: {summary['n_ok']}/{summary['n_tasks']} ok, "
          f"{summary['n_failed']} failed")
    if summary.get("score_summary", {}).get("n_items"):
        print(sr.format_table(summary["score_summary"]))
        print(f"report: {os.path.join(args.out, 'pilot_report.md')}")
    return 1 if summary["n_failed"] else 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Judge infrastructure: the independent observers of DESIGN §8.6 I1-I3.

A checker is only as trustworthy as the data it reads.  The three helpers here
exist so that verdicts rest on **independent observation** rather than on what
the system under test says about itself (N8/BA-1):

* :class:`StateObserver` (I1) -- reads CWS from an out-of-band source and
  returns ``{"observed": ..., "claimed": ..., "mismatch": ...}``; ``observed``
  always wins.
* :class:`SideEffectAudit` (I2) -- records every side effect from *outside* the
  SUT; this is the trail the N1 invariant gate evaluates.
* :class:`IndependentParser` (I3) -- parses artefacts with an implementation
  that is not the producer's, so a shared import/export bug cannot hide.

They are deliberately dependency-free: the harness plugs in whatever backend
is available (db, files, pydicom, SimpleITK) through small adapters.
"""

from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Callable, Dict, List, Optional, Sequence

from oracles.evidence_keys import SELF_REPORTED_FLAGS, strip_self_reported


class StateObserver:
    """I1: replace self-reported conclusion flags with observed state."""

    def __init__(self, reader: Callable[[str], Dict[str, Any]]):
        """``reader(case_id) -> the authoritative CWS`` (from db/files, not
        from the SUT's response)."""
        self._reader = reader

    def observe(self, case_id: str, sut_state: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        observed = self._reader(case_id) or {}
        split = strip_self_reported(observed)
        result = {
            "observed": split["observed"],
            "claimed": split["claimed"],
            "mismatch": {},
            "self_report_mismatch": [],
        }
        if sut_state is not None:
            sut_split = strip_self_reported(sut_state)
            for key, claimed_val in split["claimed"].items():
                if claimed_val is None:
                    continue
                # a claimed flag with no observed support is a self-report
                # error -- surface it so CSMR can count it (BA-1 follow-through)
                path = key.split(".")
                node = sut_state
                for p in path:
                    node = (node or {}).get(p) if isinstance(node, dict) else None
                if node is not None and node != claimed_val:
                    result["self_report_mismatch"].append(
                        {"flag": key, "claimed": claimed_val, "sut_says": node})
            # a conclusion flag that the OBSERVED state does not support is a
            # self-report error (N8) -- this is where "claimed completed" while
            # the state is still draft gets caught.
            for k in ("completed", "verified", "roundtrip_ok"):
                claimed_anywhere = split["claimed"].get(f"plan.{k}", split["claimed"].get(k))
                sut_says = sut_split["claimed"].get(f"plan.{k}", sut_split["claimed"].get(k))
                if (claimed_anywhere or sut_says) and not _supports(split["observed"], k):
                    result["mismatch"][k] = True
                    result["self_report_mismatch"].append(
                        {"flag": k, "claimed": bool(claimed_anywhere or sut_says),
                         "observed_supports": False})
        return result


def _supports(observed: Dict[str, Any], flag: str) -> bool:
    """Is a conclusion flag backed by structure in the observed state?"""
    plan = observed.get("plan") or {}
    dose = observed.get("dose") or {}
    guide = observed.get("guide") or {}
    if flag == "completed":
        return plan.get("status") == "final"
    if flag == "verified":
        return bool(dose.get("computed"))
    if flag == "roundtrip_ok":
        return bool((observed.get("interop") or {}).get("last_export"))
    return True


class SideEffectAudit:
    """I2: an append-only trail of side effects, produced out of band."""

    def __init__(self, sink: Optional[List[Dict[str, Any]]] = None):
        self.entries: List[Dict[str, Any]] = sink if sink is not None else []
        self._seq = 0

    def record(self, kind: str, *, at: Optional[str] = None, **fields: Any) -> Dict[str, Any]:
        self._seq += 1
        entry = {"kind": kind, "at": at or f"step-{self._seq:06d}", "seq": self._seq, **fields}
        self.entries.append(entry)
        return entry

    def tool_call(self, tool: str, args: Any = None, ret: Any = None, **kw: Any):
        return self.record("tool_call", tool=tool, args=args, ret=ret, **kw)

    def file_op(self, op: str, target: str, **kw: Any):
        return self.record("file_op", op=op, target=target, **kw)

    def network_op(self, url: str, **kw: Any):
        return self.record("network_op", url=url, **kw)

    def export(self, fmt: str, path: str, **kw: Any):
        return self.record("export", format=fmt, target=path, **kw)

    def cross_case_ref(self, case_id: str, **kw: Any):
        return self.record("cross_case_ref", case_id=case_id, **kw)

    def completeness(self, expected_ops: Sequence[str]) -> Dict[str, Any]:
        """DESIGN §8.6 I2: every side effect must appear exactly once.

        ``expected_ops`` is the harness's own count of what the SUT did (from
        the syscall/db layer), so a missing entry is a *trailer* gap, not a
        judgement call.
        """
        seen = [e.get("op_id") or e.get("target") or e.get("tool") or e.get("url")
                for e in self.entries]
        missing = [op for op in expected_ops if op not in seen]
        return {
            "n_expected": len(expected_ops),
            "n_recorded": len(self.entries),
            "missing": missing,
            "completeness": (1.0 - len(missing) / len(expected_ops)) if expected_ops else 1.0,
        }


class IndependentParser:
    """I3: parse artefacts with an implementation the producer does not own."""

    def __init__(self, nifti=None, dicom=None, pdf=None):
        """Each backend is a callable returning a plain dict; pass only what is
        available.  Missing backends degrade to an evidence gap, never a pass.
        """
        self._nifti = nifti
        self._dicom = dicom
        self._pdf = pdf

    def parse(self, fmt: str, path: str) -> Dict[str, Any]:
        fmt = (fmt or "").lower()
        try:
            if fmt == "nifti":
                if self._nifti is None:
                    return {"ok": False, "reason": "no nifti backend", "independent": False}
                return {"ok": True, "parsed": self._nifti(path), "independent": True}
            if fmt in ("dicom", "rt_dose", "rt_struct", "rt_plan"):
                if self._dicom is None:
                    return {"ok": False, "reason": "no dicom backend", "independent": False}
                return {"ok": True, "parsed": self._dicom(path), "independent": True}
            if fmt == "pdf":
                if self._pdf is None:
                    return {"ok": False, "reason": "no pdf backend", "independent": False}
                return {"ok": True, "parsed": self._pdf(path), "independent": True}
            return {"ok": False, "reason": f"unhandled format {fmt!r}", "independent": False}
        except Exception as exc:  # noqa: BLE001 -- a parse failure is a finding
            return {"ok": False, "reason": repr(exc), "independent": True}

    @staticmethod
    def semantic_normalise(dicom: Dict[str, Any]) -> Dict[str, Any]:
        """N11 / R-b: drop the fields that *must* change on re-export.

        ``dicom_rt_exporter`` mints ``generate_uid()`` and ``datetime.now()``
        per export, so byte comparison is meaningless; only normalised
        semantics are.
        """
        volatile = {
            "SOPInstanceUID", "SeriesInstanceUID", "StudyInstanceUID",
            "ImplementationClassUID", "FrameOfReferenceUID",
            "StudyDate", "StudyTime", "StructureSetDate", "StructureSetTime",
            "InstanceCreationDate", "InstanceCreationTime",
        }
        return {k: v for k, v in dicom.items() if k not in volatile}


def default_nifti_backend():
    """SimpleITK-backed reader, used when available (I3 in production)."""
    def read(path: str) -> Dict[str, Any]:
        import SimpleITK as sitk
        img = sitk.ReadImage(path)
        return {
            "dims": list(img.GetSize()),
            "origin": list(img.GetOrigin()),
            "spacing": list(img.GetSpacing()),
            "direction": list(img.GetDirection()),
            "dtype": img.GetPixelIDTypeAsString(),
        }
    return read


def default_dicom_backend():
    """pydicom-backed reader with volatile tags stripped."""
    def read(path: str) -> Dict[str, Any]:
        import pydicom
        ds = pydicom.dcmread(path)
        raw = {k: str(v) for k, v in ds.items() if hasattr(v, "value")}
        return IndependentParser.semantic_normalise(raw)
    return read


def default_pdf_backend():
    def read(path: str) -> Dict[str, Any]:
        data = open(path, "rb").read()
        import re
        return {
            "nbytes": len(data),
            "has_header": data.startswith(b"%PDF-"),
            "has_eof": b"%%EOF" in data[-2048:],
            "pages": len(re.findall(rb"/Type\s*/Page[^s]", data)),
        }
    return read

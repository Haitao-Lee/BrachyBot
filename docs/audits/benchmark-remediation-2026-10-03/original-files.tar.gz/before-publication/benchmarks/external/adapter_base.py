"""EXT adapter contract (DESIGN §25.5, appendix K).

One adapter per external benchmark.  Its only job is **protocol translation**:

* it must NOT modify the upstream repository (which lives read-only under
  ``external/<ext_id>/vendor/``);
* it must NOT implement its own scoring -- :meth:`ExtAdapter.score` calls the
  upstream evaluator verbatim;
* it must NOT relax a judgement for any particular SUT.

The uniform ``record`` it emits is what enters ``run_manifest`` and the
External Capability Anchors table.
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional, Sequence

# DESIGN §25.9 -- the unified eight-state outcome
PARTIAL_STATUS = (
    "COMPLETED", "PARTIAL", "NEEDS_CLARIFICATION", "BLOCKED_BY_DEPENDENCY",
    "REFUSED_FOR_SAFETY", "FAILED_TOOL", "FAILED_VERIFICATION", "INFRA_FAILED",
)


class ExtAdapter:
    """Base class; each ``external/<ext_id>/adapter/adapter.py`` subclasses it."""

    EXT_ID: str = "EXT-?"
    #: DESIGN §25.1 -- kept here so a mismatch is visible at load time
    GRADE_R: str = "R0"
    GRADE_C: str = "C3"
    PANELS: Sequence[str] = ()

    # -- to implement ------------------------------------------------------
    def list_tasks(self) -> List[str]:
        """Upstream task ids, in a stable order."""
        raise NotImplementedError

    def build_input(self, task_id: str) -> Any:
        """Whatever the upstream runner needs (prompt / scene / workdir)."""
        raise NotImplementedError

    def run_task(self, task_id: str, sut_handle: Any, budget: Dict[str, int]) -> Dict[str, Any]:
        """Execute one task and return the uniform record."""
        raise NotImplementedError

    def score(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """Call the **upstream** evaluator.  Never re-implement scoring."""
        raise NotImplementedError

    # -- uniform record ----------------------------------------------------
    @staticmethod
    def record(
        *,
        ext_id: str,
        source_task_id: str,
        prompt_or_scene: Any,
        sut_output: Optional[Dict[str, Any]] = None,
        upstream_verdict: Optional[Dict[str, Any]] = None,
        derived: Optional[Dict[str, Any]] = None,
        infra_failed: bool = False,
    ) -> Dict[str, Any]:
        d = {
            "tool_call_count": 0, "wall_clock_s": 0.0, "retries": 0,
            "partial_status": "COMPLETED",
            **(derived or {}),
        }
        if infra_failed:
            d["partial_status"] = "INFRA_FAILED"
        if d.get("partial_status") not in PARTIAL_STATUS:
            raise ValueError(f"partial_status must be one of {PARTIAL_STATUS}")
        return {
            "ext_id": ext_id,
            "source_task_id": source_task_id,
            "prompt_or_scene": prompt_or_scene,
            "sut_output": sut_output or {},
            "upstream_verdict": upstream_verdict or {},
            "derived": d,
            "infra_failed": bool(infra_failed),
        }

    # -- isolation (DESIGN §25.8) -----------------------------------------
    FORBIDDEN_WRITE_ROOTS = (
        "BrachyBot/session/", "BrachyBot/case/",
        "BrachyBot/runtime/", "BrachyBot/report/",
    )

    @classmethod
    def audit_isolation(cls, mtimes_before: Dict[str, float],
                        mtimes_after: Dict[str, float]) -> List[str]:
        """Return the forbidden roots whose mtime changed (empty == clean).

        DESIGN §25.8: finding any change **voids** the EXT run.
        """
        out = []
        for root in cls.FORBIDDEN_WRITE_ROOTS:
            b = mtimes_before.get(root)
            a = mtimes_after.get(root)
            if b is not None and a is not None and a != b:
                out.append(root)
        return out


class OfflineBundleAdapter(ExtAdapter):
    """DESIGN §12.1 ``offline_bundle`` -- for systems that cannot speak HTTP.

    Commercial TPS cannot implement an online SAA, but they can export DICOM
    RT.  This adapter consumes a ``bundle_out/`` directory and scores it with
    whatever the harness supplies (never with the vendor's own tools).
    """

    def load_bundle(self, out_dir: str) -> Dict[str, Any]:
        manifest = os.path.join(out_dir, "MANIFEST.sha256")
        files = {}
        for name in ("dose.nii.gz", "dose.dcm", "structures.dcm", "plan.dcm",
                     "guide.stl", "report.pdf", "report.json",
                     "final_state.json", "replies.json"):
            p = os.path.join(out_dir, name)
            if os.path.isfile(p):
                files[name] = p
        return {
            "out_dir": out_dir,
            "files": files,
            "has_manifest": os.path.isfile(manifest),
            "final_state": self._read_json(files.get("final_state.json")),
            "replies": self._read_json(files.get("replies.json")),
        }

    @staticmethod
    def _read_json(path: Optional[str]) -> Any:
        if not path:
            return None
        try:
            with open(path, encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:  # noqa: BLE001
            return None
